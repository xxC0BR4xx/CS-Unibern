//Jara Zihlman (20-117-032)
//Vithusan Ramalingam (21-105-515)
//Jan Ellenberger (21-103-643)

public class WinterIsComing {

    public static void main(String[] args) {
        
        System.out.println("Winter is coming");

        System.out.print("Winter\n" + "is\n" + "coming\n");

    }
    
}
